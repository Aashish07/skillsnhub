from django.apps import AppConfig


class ArenaConfig(AppConfig):
    name = 'arena'
